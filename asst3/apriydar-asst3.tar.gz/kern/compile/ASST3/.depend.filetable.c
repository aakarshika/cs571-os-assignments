filetable.o: ../../syscall/filetable.c ../../include/types.h \
  ../../include/kern/types.h includelinks/kern/machine/types.h \
  includelinks/machine/types.h ../../include/kern/errno.h \
  ../../include/lib.h ../../include/cdefs.h opt-noasserts.h \
  ../../include/openfile.h ../../include/spinlock.h \
  includelinks/machine/spinlock.h ../../include/filetable.h \
  ../../include/limits.h ../../include/kern/limits.h
