beep_ltimer.o: ../../dev/lamebus/beep_ltimer.c ../../include/types.h \
  ../../include/kern/types.h includelinks/kern/machine/types.h \
  includelinks/machine/types.h ../../include/lib.h ../../include/cdefs.h \
  opt-noasserts.h ../../dev/generic/beep.h ../../dev/lamebus/ltimer.h \
  autoconf.h
